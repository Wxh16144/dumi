---
nav:
  title: 插件
  order: 1
group: 介绍
---

# 如何工作

dumi 是基于 Umi 打造的静态站点框架，所以同时也继承了 Umi 强大的插件机制，并在之上做了扩展，以满足更多的场景需求。

<embed src="../.upstream/plugin.md"></embed>

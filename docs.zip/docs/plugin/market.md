---
title: 插件市场
group: 介绍
order: 4
toc: null
---

<!-- 此处你将看到超棒的插件合集。<= 超过 10 个插件俺就取消注释！-->

阅读更多关于 [如何使用插件](./index.md#配置)，或 [如何编写属于你自己的插件](./new.md) 并与社区分享！

## 社区插件

- [**color-chunk**](https://github.com/Wxh16144/dumi-plugin-color-chunk#readme): 美化内联代码颜色块儿 \`#f00\`。
- TBD: [提交我的插件](https://github.com/umijs/dumi/edit/master/docs/plugin/market.md)

## 更多插件

查找 [NPM 上所有可用的插件](https://www.npmjs.com/search?q=keywords%3Adumi-plugin)。

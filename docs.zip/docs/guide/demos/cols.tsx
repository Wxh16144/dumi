import React from 'react';

export default () => <>Demo 分栏演示</>;
